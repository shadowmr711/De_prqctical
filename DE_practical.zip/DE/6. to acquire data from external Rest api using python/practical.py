import requests
import pandas as pd
import time

print("Libraries ready")

url = "https://jsonplaceholder.typicode.com/users"

start_time = time.time()
response = requests.get(url)
end_time = time.time()

print("Status Code:", response.status_code)

data = response.json()

print("First Record From API:")
print(data[0])

df = pd.json_normalize(data)

print("\nFirst 5 Rows:")
print(df.head())

df.to_csv("users_data.csv", index=False)

print("\nTotal Records:", len(df))
print("User data saved successfully")

post_url = "https://jsonplaceholder.typicode.com/posts"

post_start = time.time()
post_response = requests.get(post_url)
post_end = time.time()

print("\nPosts API Status Code:", post_response.status_code)

posts_data = post_response.json()

posts_df = pd.json_normalize(posts_data)

print("\nFirst 5 Posts:")
print(posts_df.head())

posts_df.to_csv("posts_data.csv", index=False)

print("\nTotal Posts:", len(posts_df))
print("Posts data saved successfully")

print("\nAPI Response Time:")
print("Users API:", round(end_time - start_time, 4), "seconds")
print("Posts API:", round(post_end - post_start, 4), "seconds")

print("\nPractical 6 Completed Successfully")