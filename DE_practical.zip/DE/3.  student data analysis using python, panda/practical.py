import pandas as pd

df = pd.read_csv("StudentData.csv")

print("Complete Student Data:")
print(df.to_string())

print("\nMissing Values:")
print(df.isnull().sum())

print("\nDataset Information:")
df.info()

print("\nFirst 3 Records:")
print(df.head(3))

print("\nStatistical Information:")
print(df.describe())

print("\nStudents by Gender:")
print(df["Gender"].value_counts())

print("\nAverage Marks:", df["Marks"].mean())
print("Highest Marks:", df["Marks"].max())
print("Lowest Marks:", df["Marks"].min())