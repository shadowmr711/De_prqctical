
# Practical: Load and Analyze a Dataset Using Pandas
# and Perform Data Visualization

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Load the Titanic dataset
url = "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"
df = pd.read_csv(url)

# 2. Display the first five rows
print("\n1. FIRST FIVE ROWS")
print(df.head())

# 3. Display the last five rows
print("\n2. LAST FIVE ROWS")
print(df.tail())

# 4. Display five random rows
print("\n3. RANDOM FIVE ROWS")
print(df.sample(5, random_state=42))

# 5. Display dataset shape
print("\n4. DATASET SHAPE")
print(df.shape)

# 6. Display column names
print("\n5. COLUMN NAMES")
print(df.columns.tolist())

# 7. Display dataset information
print("\n6. DATASET INFORMATION")
df.info()

# 8. Display numerical columns
print("\n7. NUMERICAL COLUMNS")
print(df.select_dtypes(include="number").columns.tolist())

# 9. Display categorical columns
print("\n8. CATEGORICAL COLUMNS")
print(df.select_dtypes(include=["object", "category"]).columns.tolist())

# 10. Display statistical summary
print("\n9. STATISTICAL SUMMARY")
print(df.describe())

# 11. Count missing values
print("\n10. MISSING VALUES")
print(df.isnull().sum())

# 12. Calculate missing value percentages
print("\n11. MISSING VALUE PERCENTAGE")
print((df.isnull().mean() * 100).round(2))

# 13. Display total missing values
print("\n12. TOTAL MISSING VALUES")
print(df.isnull().sum().sum())

# 14. Display survival count
print("\n13. SURVIVAL COUNT")
print(df["Survived"].value_counts())

# 15. Display survival by gender
print("\n14. SURVIVAL BY GENDER")
print(df.groupby("Sex")["Survived"].agg(
    ["count", "sum", "mean"]
))

# Set graph style
sns.set_theme(style="whitegrid")

# Graph 1: Survival count
plt.figure(figsize=(7, 5))
sns.countplot(data=df, x="Survived")
plt.title("Titanic Passenger Survival Count")
plt.xlabel("Survived (0 = No, 1 = Yes)")
plt.ylabel("Number of Passengers")
plt.tight_layout()
plt.show()

# Graph 2: Survival by gender
plt.figure(figsize=(7, 5))
sns.countplot(data=df, x="Sex", hue="Survived")
plt.title("Survival by Gender")
plt.xlabel("Gender")
plt.ylabel("Number of Passengers")
plt.tight_layout()
plt.show()

# Graph 3: Passengers by class
plt.figure(figsize=(7, 5))
sns.countplot(data=df, x="Pclass")
plt.title("Passengers by Ticket Class")
plt.xlabel("Passenger Class")
plt.ylabel("Number of Passengers")
plt.tight_layout()
plt.show()

# Graph 4: Age distribution
plt.figure(figsize=(8, 5))
sns.histplot(data=df, x="Age", bins=20, kde=True)
plt.title("Age Distribution of Passengers")
plt.xlabel("Age")
plt.ylabel("Frequency")
plt.tight_layout()
plt.show()

# Graph 5: Correlation heatmap
numeric_df = df.select_dtypes(include="number")
correlation = numeric_df.corr()

plt.figure(figsize=(10, 7))
sns.heatmap(
    correlation,
    annot=True,
    cmap="coolwarm",
    fmt=".2f",
    linewidths=0.5
)
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.show()

print("\nPractical completed successfully.")
