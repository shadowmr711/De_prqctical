import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

url = "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"

df = pd.read_csv(url)

print("Dataset Shape:")
print(df.shape)

print("First Five Records:")
print(df.head())

print("Last Five Records:")
print(df.tail())

print("Random Five Records:")
print(df.sample(5, random_state=42))

print("Dataset Information:")
df.info()

print("Column Names:")
print(df.columns.tolist())

print("Data Types:")
print(df.dtypes)

num_cols = df.select_dtypes(include=np.number).columns.tolist()
cat_cols = df.select_dtypes(exclude=np.number).columns.tolist()

print("Numerical Columns:")
print(num_cols)

print("Categorical Columns:")
print(cat_cols)

print("Statistical Information:")
print(df.describe())

print("Number of Rows:", df.shape[0])
print("Number of Columns:", df.shape[1])

print("Missing Values:")
print(df.isnull().sum())

missing_percentage = (df.isnull().sum().sum() / df.size) * 100
print("Missing Value Percentage:", missing_percentage)

sns.set_style("whitegrid")
plt.figure(figsize=(8, 5))
sns.countplot(data=df, x="Pclass")
plt.title("Number of Passengers in Each Passenger Class")
plt.xlabel("Passenger Class")
plt.ylabel("Number of Passengers")
plt.show()