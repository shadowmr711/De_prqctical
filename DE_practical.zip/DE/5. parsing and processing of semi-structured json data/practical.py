import requests
import json
import pandas as pd

url = "https://jsonplaceholder.typicode.com/users"

response = requests.get(url)

print(response.status_code)
print(response.text[:500])

data = response.json()

print(type(data))

print(data[0])

user = data[0]

print("ID:", user["id"])
print("Name:", user["name"])
print("Username:", user["username"])
print("Email:", user["email"])
print("Phone:", user["phone"])

address = user["address"]

print("Street:", address["street"])
print("City:", address["city"])
print("Zipcode:", address["zipcode"])

geo = address["geo"]

print("Latitude:", geo["lat"])
print("Longitude:", geo["lng"])

company = user["company"]

print("Company:", company["name"])
print("Catch Phrase:", company["catchPhrase"])
print("Business:", company["bs"])

records = []

for user in data:
    address = user.get("address", {})
    geo = address.get("geo", {})
    company = user.get("company", {})

    record = {
        "User-ID": user.get("id"),
        "Name": user.get("name"),
        "Username": user.get("username"),
        "Email": user.get("email"),
        "Phone": user.get("phone"),
        "Street": address.get("street"),
        "City": address.get("city"),
        "Zipcode": address.get("zipcode"),
        "Latitude": geo.get("lat"),
        "Longitude": geo.get("lng"),
        "Company": company.get("name")
    }

    records.append(record)

df = pd.DataFrame(records)

print(df.head())
print(df.shape)
print(df.columns)
print(df.dtypes)

df["Latitude"] = pd.to_numeric(df["Latitude"])
df["Longitude"] = pd.to_numeric(df["Longitude"])

print(df.dtypes)

city_count = df["City"].value_counts()

print(city_count)

print(df[["Name", "Company"]])

result = df[df["City"] == "McKenziehaven"]

print(result)

sorted_df = df.sort_values("Name")

print(sorted_df[["User-ID", "Name", "City"]])

selected_data = df[["User-ID", "Name", "Email", "City", "Company"]]

print(selected_data)

city = user.get("address", {}).get("city", "Unknown")

company_name = user.get("company", {}).get("name", "Unknown")

print(city)
print(company_name)

df.to_csv("users_transformed.csv", index=False)

print("File saved successfully")

new_df = pd.read_csv("users_transformed.csv")

print(new_df.head())
print(new_df.shape)